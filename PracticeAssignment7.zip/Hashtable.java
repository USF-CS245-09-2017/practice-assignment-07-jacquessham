
public class Hashtable<K,V>{
	public class HashNode<K,V>{
		K key;
		V value;
		HashNode next;
		
		public HashNode(K key,V value){
			this.key = key;
			this.value = value;
			next = null;
		}
		
		public void setNext(HashNode next){
			this.next = next;
		}
		
		public boolean hasNext(){
			if (next != null)
				return true;
			return false;
		}
	}
	
	private HashNode[] arr;
	private int elements;
	
	public Hashtable(){
		arr = new HashNode[5];
		elements = 0;
	}
	
	public void put(K key, V value){
		int pos = Math.abs(key.hashCode())%arr.length;
		HashNode node = new HashNode<K,V>(key,value);
		node.setNext(arr[pos]);
		arr[pos] = node;
		elements++;
	}
	
	public V get(K key){
		int pos = Math.abs(key.hashCode())%arr.length;
		HashNode temp = arr[pos];
		while (temp != null){
			if (temp.key == key)
				return (V) temp.value;
			temp = temp.next;
		}
		return null;
	}
	
	public V remove(K key){
		int pos = Math.abs(key.hashCode())%arr.length;
		HashNode pointer = arr[pos];
		if (pointer.value == null)
			return null;
		if (pointer.key == key){
			arr[pos] = pointer.next;
			elements--;
			return (V)pointer.value;
		}
		while (pointer.hasNext()){
			if(pointer.next.key == key){
				V temp = (V)pointer.next.value;
				pointer.next = pointer.next.next;
				elements--;
				return temp;
			}
			pointer = pointer.next;	
		}
		
		return null;
	}
	
	public boolean containsKey(K key){
		int pos = Math.abs(key.hashCode())%arr.length;
		HashNode temp = arr[pos];
		while (temp != null){
			if (temp.key == key)
				return true;
			temp = temp.next;
		}
		return false;
		
	}
	
}
